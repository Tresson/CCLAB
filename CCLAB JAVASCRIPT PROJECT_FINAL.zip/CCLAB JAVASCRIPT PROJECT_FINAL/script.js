
// GLOBAL VARIABLES
var logDiv = document.getElementById("log");
var logDetailsDiv = document.getElementById("logDetails");
var divPloatje = document.getElementById('ploatje');
var mouse = {
    x: -100,
    y: -100
};

fixMask();


if ('ontouchstart' in document.documentElement) {
    divPloatje.addEventListener('touchmove', touchMove, false);
    divPloatje.addEventListener('touchstart', touchStart, false);
    divPloatje.addEventListener('touchend', touchEnd, false);
} else {
    divPloatje.addEventListener('mousemove', touchMove, false);
}


function touchStart(e) {
    console.debug("Touch Start! " + e.type + " event=" + inspect(e));
    e.preventDefault(); 
    return false;
}

function touchMove(e) {

    if (e.touches == null) {
        mouse = getMouse(e, divPloatje);
        console.debug("Mouse Move");
    } else {
        var targetEvent = e.touches.item(0);
        mouse.x = targetEvent.clientX;
        mouse.y = targetEvent.clientY;
    }

    e.preventDefault(); 
    return false;
}

function touchEnd(e) {
    console.debug("touchEnd (!)");
}

function fixMask() {
    webkitRequestAnimationFrame(fixMask);
    var strImage = '-webkit-radial-gradient(' + mouse.x + 'px ' + mouse.y + 'px,100px 100px, rgba(0, 0, 0, 1) 0%,rgba(0, 0, 0, 1) 10%, rgba(255, 255, 255, 0.1) 60%, rgba(255, 255, 255, 0.1) 100%)';
    divPloatje.style.WebkitMaskImage = strImage;
}

function getMouse(e, canvas) {
    var element = canvas,
        offsetX = 0,
        offsetY = 0,
        mx, my;

    if (element.offsetParent !== undefined) {
        do {
            offsetX += element.offsetLeft;
            offsetY += element.offsetTop;
        } while ((element = element.offsetParent));
    }

    mx = e.pageX - offsetX;
    my = e.pageY - offsetY;

    return {
        x: mx,
        y: my
    };
}

function log(text) {
    logDiv.innerHTML = text;
}

function inspect(obj) {
    if (typeof obj === "undefined") {
        return "undefined";
    }
    var _props = [];

    for (var i in obj) {
        _props.push(i + " : " + obj[i]);
    }
    return " {" + _props.join(",<br>") + "} ";
}

///////////////////////////////////////////

//SNOW

function Flake(x,y,vx,vy,s) {
    this.x = x;
    this.y = y;
    this.vx = vx;
    this.mx = Math.abs(vx * 2);
    this.vy = vy;
    this.my = vy;
    this.s = s;
    this.seed = Math.random() * 1e12;
    ///
    var canvas = document.createElement('canvas'),
        context = canvas.getContext('2d'),
        height = canvas.height = s * 2,
        width = canvas.width = s * 2,
        grad = context.createRadialGradient(s, s, 1, s, s, s);
    grad.addColorStop(0, 'rgba(255,255,255,1)');
    grad.addColorStop(1, 'rgba(255,255,255,0)');
    context.beginPath();
    context.arc(s, s, s, 0, Math.PI * 2, !0);
    context.fillStyle = grad;
    context.fill();
    context.closePath();
    
    this.img = canvas;
}

Flake.prototype = {
    constructor: Flake,
    update: function() {
        this.x += this.vx;
        this.y += this.vy;
        
        if( this.x > width + this.s * 2 ) {
            this.x = 0 - this.s * 2;
        }
        if( this.x < 0 - this.s * 2 ) {
            this.x = width + this.s * 2;
        }
        
        if( this.y > height + this.s * 2 ) {
            this.y = 0 - this.s * 2;
        }
        if( this.y < 0 - this.s * 2 ) {
            this.y = height + this.s * 2;
        }
        if( Math.abs(this.vx) > this.mx ) {
            this.vx = this.vs > 0 ? this.mx : -1 * this.mx;
        }
        this.vx += Math.sin(Date.now() + this.seed)/100;
        if( this.vy < this.my ) {
            this.vy += this.my/10;
        }
    }
};

var canvas, context, height, width, snow_count, hand_size, snow;

setTimeout(init, 10);

function init() {
    canvas = document.getElementById('canvas');
    context = canvas.getContext('2d');
    height = canvas.height = document.body.offsetHeight;
    width = canvas.width = document.body.offsetWidth;

    snow_count = 700;
    hand_size = 80;
    snow = [];

    for( var i = 0; i < snow_count; i++ ) {
    
        var x = Math.random() * width,
            y = Math.random() * height,
            s = Math.random() * 2.5 + 2.5,
            vx = Math.random() * 2 - 1,
            vy = Math.random() + s/2.5;
        snow.push(new Flake(x,y,vx,vy,s));
    }
    
    update();
    render();
}

function update() {
    for( var i = 0; i < snow_count; i++ ) {
        snow[i].update();
    }
    setTimeout(update, 1000/60);
}

function render() {
    context.clearRect(0, 0, width, height);
    for( var i = 0; i < snow_count; i++ ) {
        context.drawImage(snow[i].img, snow[i].x - snow[i].s, snow[i].y - snow[i].s);
    }
    requestAnimationFrame(render);
}

